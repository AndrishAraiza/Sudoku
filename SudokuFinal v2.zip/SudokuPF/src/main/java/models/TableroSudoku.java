/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;


import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import views.Gameover;
import models.Tablero;
import views.Gameplay;
import views.OverScreen;


 /**
 *
 * @author andrisharaizaespinoza
 */
public final class TableroSudoku extends JPanel {
    /**
    * Atributos para la creacion del tablero
    */
    private JTextField[][] listaTxt;   // Matriz de campos de texto para celdas del tablero
    private int txtAncho;             // Ancho de un campo de texto
    private int txtAltura;            // Altura de un campo de texto
    private int txtMargen;            // Margen entre celdas del tablero
    private int txtTamañoLetra;       // Tamaño de letra en los campos de texto
    private Color panelBackground;    // Color de fondo del panel
    private Color txtBackground1;     // Color de fondo de celdas 
    private Color txtForeground1;     // Color de texto de celdas 
    private Color txtBackground2;     // Color de fondo de celdas 
    private Color txtForeground2;     // Color de texto de celdas 
    private Color txtBackground3;     // Color de fondo de celdas 
    private Color txtForeground3;     // Color de texto de celdas 
    private Tablero sudoku;           // Instancia de la clase Tablero
    private ArrayList<JTextField> listaTxtAux; // Lista de campos de JTextField
    private ArrayList<JTextField> listaTxtGenerados;
    
    
    /**
    * Constructor de la clase 
    *
    */
    public TableroSudoku(){
        iniciarComponentes();
   
    }
    
    
    /**
    * Inicializamos los componentes de la matriz
    */
    public void iniciarComponentes(){
     
        listaTxt = new JTextField[9][9];
        txtAncho = 35;
        txtAltura = 36;
        txtMargen = 4;
        txtTamañoLetra = 27;
        //Volores predeterminados de los fondos del tablero
        panelBackground = Color.BLACK;
        txtBackground1 = Color.WHITE;
        txtForeground1 = Color.BLACK;
        txtBackground2 = Color.WHITE;
        txtForeground2 = Color.BLACK;
        txtBackground3 = Color.WHITE;
        txtForeground3 = Color.BLACK;
        
        
        sudoku = new Tablero();
        listaTxtAux = new ArrayList<>();
        listaTxtGenerados = new ArrayList<>();
    }
    
    /**
    * Este metodo crea y ordena las celdas del tablero
    */
    public void crearSudoku(){
        this.setLayout(null);
        // Ordenamiento del tablero
        this.setSize(txtAncho * 9 + (txtMargen * 4), txtAltura * 9 + (txtMargen * 4));
        // Color de fondo del panel
        this.setBackground(panelBackground);
        crearCamposTxt();
    }
    
    /**
    * Crea los campos de texto que forman el tablero de Sudoku.
    */
    public void crearCamposTxt() {
        int x = txtMargen;
        int y = txtMargen;
        // Iterar a través de las filas del tablero
        for(int i = 0; i< listaTxt.length; i++){
            // Iterar a través de las columnas del tablero
            for(int j = 0; j < listaTxt[0].length; j++){
            
                JTextField txt = new JTextField(); // Crea un nuevo objeto de campo de texto
                this.add(txt); // Agrega el campo de texto al panel actual
                txt.setBounds(x, y, txtAncho, txtAltura); // Establece la posición y el tamaño del campo de texto
                txt.setBackground(txtBackground1); // Establece el color de fondo del campo de texto (tipo 1)
                //txt.setForeground(txtBackground1); // Establece el color del texto del campo de texto (tipo 1)
                txt.setFont(new Font("Arial", Font.BOLD, 21)); // Establece la fuente y el tamaño de la letra en el campo de texto
                txt.setVisible(true); // Hace visible el campo de texto en la interfaz
                txt.setEditable(false); // Deshabilita la edición del campo de texto
                txt.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Cambia el cursor al estilo de una mano al pasar sobre el campo de texto
                txt.setBorder(BorderFactory.createLineBorder(panelBackground, 1)); // Establece un borde alrededor del campo de texto, con el color del panel de fondo
                x += txtAncho; // Desplaza la posición 'x' hacia la derecha en el ancho de un campo de texto, al crear la siguiente celda.
                
                // Añadir un margen si la celda es múltiplo de 3
                if((j+1) %3==0){
                    x+=txtMargen; // Si la columna es múltiplo de 3, añade un margen adicional entre celdas.
                }
                listaTxt[i][j] = txt; // Almacena el campo de texto recién creado en la matriz 'listaTxt'.
                generarEventos(txt); // Agrega eventos de mouse a los campos de texto
           }
            
            x = txtMargen; // Reinicia la posición 'x' al margen inicial, para comenzar una nueva fila de celdas.
            y += txtAltura; // Desplaza la posición 'y' hacia abajo en la altura de un campo de texto, para crear la siguiente fila de celdas.

            
            // Añadir un margen vertical si la fila es múltiplo de 3
            if((i+1)%3 == 0){
                y += txtMargen; // Si la fila es múltiplo de 3, añade un margen vertical adicional entre bloques de celdas.
            }
    }
}

    
    /**
     * Este metodo genera los eventos dentro del tablero como la seleccion de la 
     * casilla
     * 
     */
    public void generarEventos(JTextField txt){
        
        MouseListener evento = new MouseListener() {
            
            
            @Override
            public void mouseClicked(MouseEvent e) {
                
            }

            @Override
            public void mousePressed(MouseEvent e) {
                pressed(txt); // Llama al método 'pressed' cuando se presiona el campo de texto
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                
            }

            @Override
            public void mouseExited(MouseEvent e) {
             
            }
        };
        
        KeyListener eventoTecla = new KeyListener() {
            @Override
            /**
            * Metodo para poder ingresar valores del 1-9 de acuerdo al codigo SCII
            */
            public void keyTyped(KeyEvent e) {
                
            }
            @Override
            public void keyPressed(KeyEvent e) {

                 if (e.getKeyChar() >= 49 && e.getKeyChar() <= 57) {
                        txt.setText(String.valueOf(e.getKeyChar()));
                    }
                        
                    }
            

            @Override
            public void keyReleased(KeyEvent e) {
            }
        };
        
        //Le asignamos los objetos al metodo
        txt.addMouseListener(evento);
        txt.addKeyListener(eventoTecla);
    }
    
    /**
    * Responde al evento de presionar un campo de texto seleccionado.
    */
    public void pressed(JTextField txt) {
        // Iterar a través de la lista de campos de texto auxiliar
        for(JTextField jTxt : listaTxtAux){
            jTxt.setBackground(txtBackground1);
            jTxt.setForeground(Color.BLACK);
            jTxt.setBorder(BorderFactory.createLineBorder(panelBackground,1));
        }
            listaTxtAux.clear();
         
         // Iterar a través de las filas del tablero   
        for(int i = 0; i <listaTxt.length; i++){
            // Iterar a través de las columnas del tablero
            for (int j = 0; j < listaTxt[0].length; j++){
                if(listaTxt[i][j] == txt){
                    // Cambia los colores de celdas relacionadas al campo de texto seleccionado
                    
                    // Cambiar el color de fondo y texto de las celdas en la misma columna
                    for(int k = 0; k < listaTxt.length; k++){
                        listaTxt[k][j].setBackground(txtBackground2);
                        listaTxt[k][j].setForeground(Color.BLACK);
                        listaTxtAux.add(listaTxt[k][j]);
                    }
                    
                    // Cambiar el color de fondo y texto de las celdas en la misma fila
                    for(int k = 0; k < listaTxt[0].length; k++){
                        listaTxt[i][k].setBackground(txtBackground2);
                        listaTxt[i][k].setForeground(Color.BLACK);
                        listaTxtAux.add(listaTxt[i][k]);
                }
                    
                    // Calcular la posición de fila y columna en el bloque actual
                    int posFila = sudoku.BloqueActual(i);
                    int posColumna = sudoku.BloqueActual(j);
                    // Iterar a través de las celdas en el mismo bloque
                    for(int k = posFila-3; k <posFila; k++){            
                        for(int l = posColumna-3; l <posColumna; l++){
                            // Cambiar el color de fondo y texto de las celdas en el mismo bloque
                            listaTxt[k][l].setBackground(txtBackground2);
                            listaTxt[k][l].setForeground(Color.BLACK);
                            listaTxtAux.add(listaTxt[k][l]);
                        }
                    }
                    // Cambiar el color de fondo, texto y el borde del campo de texto seleccionado
                    
                    listaTxt[i][j].setBackground(txtBackground3);
                    listaTxt[i][j].setForeground(Color.BLACK);
                    listaTxt[i][j].setBorder(BorderFactory.createLineBorder(Color.WHITE,2));
                    return;
                    
                }
            }
        }
    }
    /**
    * Metodo que genera los numeros en el sudoku que previamente se genero
    */
    public void generarSudoku(int nivel){
        limpiarTxt();
        sudoku.generarSudoku(nivel);
        int [][] sudokuGenerado = sudoku.getTablero();
        for (int i = 0; i < listaTxt.length; i++){
            for(int j = 0; j < listaTxt[0].length; j++){
                if(sudokuGenerado[i][j]!=0){
                    listaTxt[i][j].setText(String.valueOf(sudokuGenerado[i][j]));
                    listaTxtGenerados.add(listaTxt[i][j]);
                    listaTxt[i][j].setEnabled(false);
                    
                }
            }
        }
    }
    
    /**
    * Metodo que limpia todo el tablero y deja los campos vacios
    */
    public void limpiarTxt() {
        for (int i = 0; i < listaTxt.length; i++) {
            for (int j = 0; j < listaTxt[0].length; j++) {
                listaTxt[i][j].setText("");
            }
        }
    }
    
    /**
    * Este metodo sirve para limpiar las casillas que se han modificado desde 
    * el tablero
    */
    public void limpiar() {
        for (int i = 0; i < listaTxt.length; i++) {
            for (int j = 0; j < listaTxt[0].length; j++) {

                boolean b = false;
                for (JTextField txt : listaTxtGenerados) {
                    if (listaTxt[i][j] == txt) {
                        b = true;
                        break;
                    }
                }
                if (!b) {
                    listaTxt[i][j].setText("");
                }

            }
        }
    }
    
    
    /**
    * Este metodo comprueba si el sudoku esta hecho corectamente
    */
    public void comprobar() {
        int sudo[][] = new int[9][9];
        for (int i = 0; i < listaTxt.length; i++) {
            for (int j = 0; j < listaTxt[0].length; j++) {
                if (listaTxt[i][j].getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Sudoku incompleto", "Error", JOptionPane.ERROR_MESSAGE);
                    Gameplay gm = new Gameplay();
                    gm.setVisible(true);
                    return;
                    
                } else {
                    sudo[i][j] = Integer.parseInt(listaTxt[i][j].getText());
                }
                
                
            }
        }
        sudoku.setTablero(sudo);
        if (sudoku.comprobarSudoku()) {
            JOptionPane.showMessageDialog(null, "Sudoku correcto", "Sudoku", JOptionPane.INFORMATION_MESSAGE);
            
            
            OverScreen over = new OverScreen();
            over.setVisible(true);
            
            
            
            
        } else {
            JOptionPane.showMessageDialog(null, "No hay solución", "Error", JOptionPane.ERROR_MESSAGE);
            Gameplay gm = new Gameplay();
            gm.setVisible(true);
        }

    }
    
    public void resolver(){
        sudoku.limpiarSudoku();
        for (int i = 0; i < listaTxt.length; i++) {
            for (int j = 0; j < listaTxt[0].length; j++) {
                for (JTextField txt:listaTxtGenerados) {
                    if(txt==listaTxt[i][j]){
                        sudoku.getTablero()[i][j]=Integer.parseInt(txt.getText());
                    }
                }
            }
        }

        if(sudoku.resolverTablero()){
            for (int i = 0; i < listaTxt.length; i++) {
                for (int j = 0; j < listaTxt[0].length; j++) {
                    listaTxt[i][j].setText(String.valueOf(sudoku.getTablero()[i][j]));
                }
            }
        }else{
            JOptionPane.showMessageDialog(null,"No hay solución","Error",JOptionPane.ERROR_MESSAGE);
        }

    }



    /**
    * Getters y setters de los componentes del diseño del tablero
    */
    public JTextField[][] getListaTxt() {
        return listaTxt;
    }

    public void setListaTxt(JTextField[][] listaTxt) {
        this.listaTxt = listaTxt;
    }

    public int getTxtAncho() {
        return txtAncho;
    }

    public void setTxtAncho(int txtAncho) {
        this.txtAncho = txtAncho;
    }

    public int getTxtAltura() {
        return txtAltura;
    }

    public void setTxtAltura(int txtAltura) {
        this.txtAltura = txtAltura;
    }

    public int getTxtMargen() {
        return txtMargen;
    }

    public void setTxtMargen(int txtMargen) {
        this.txtMargen = txtMargen;
    }

    public int getTxtTamañoLetra() {
        return txtTamañoLetra;
    }

    public void setTxtTamañoLetra(int txtTamañoLetra) {
        this.txtTamañoLetra = txtTamañoLetra;
    }

    public Color getPanelBackground() {
        return panelBackground;
    }

    public void setPanelBackground(Color panelBackground) {
        this.panelBackground = panelBackground;
    }

    public Color getTxtBackground1() {
        return txtBackground1;
    }

    public void setTxtBackground1(Color txtBackground1) {
        this.txtBackground1 = txtBackground1;
    }

    public Color getTxtForeground1() {
        return txtForeground1;
    }

    public void setTxtForeground1(Color txtForeground1) {
        this.txtForeground1 = txtForeground1;
    }

    public Color getTxtBackground2() {
        return txtBackground2;
    }

    public void setTxtBackground2(Color txtBackground2) {
        this.txtBackground2 = txtBackground2;
    }

    public Color getTxtForeground2() {
        return txtForeground2;
    }

    public void setTxtForeground2(Color txtForeground2) {
        this.txtForeground2 = txtForeground2;
    }

    public Color getTxtBackground3() {
        return txtBackground3;
    }

    public void setTxtBackground3(Color txtBackground3) {
        this.txtBackground3 = txtBackground3;
    }

    public Color getTxtForeground3() {
        return txtForeground3;
    }

    public void setTxtForeground3(Color txtForeground3) {
        this.txtForeground3 = txtForeground3;
    }

    
} 
    
    