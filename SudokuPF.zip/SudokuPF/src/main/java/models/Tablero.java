
package models;

import java.util.Random;
import views.Nivel;



/**
 *
 * @author andrisharaizaespinoza
 */
public class Tablero {
     
    private int tablero[][];
   /*
    Creamos la matriz del tablero de 9x9 con valores en algunas casiilas
    ya predeterminados
    */ 
    public Tablero(){
            tablero = new int[9][9];
            limpiarSudoku();
    }
    /*
    *Metodos para resolver correctamente el sudoku
    */
    //Recorren las columnas y filas de la matriz 
    public boolean resolverTablero(){
        for (int i = 0; i < tablero.length; i++){
            for (int j = 0; j < tablero[0].length; j++){
                if (tablero[i][j] ==0){
                    //si alguna de las posiciones es = 0 podemos agregar valores
                    for (int valor = 1; valor <= 9; valor++){
                      /*
                      *Restriccion a la hora de poner un valor en una casilla
                      *Que no se encuentren en la misma fila, columna o bloque
                      */
                      //Validar fila, columna y bloque
                      if(getFilas(i, valor) && getColumna(j, valor) && getBloque(i,j,valor)){
                          tablero[i][j] = valor;
                          if(resolverTablero()) return true;
                          //Back-tracking
                          tablero[i][j]=0;
                      }
                   } return false;
                }
            }
        }return true;
    } 
    /*
    *Verificacion de los bloques del tablero
    */
    public int BloqueActual(int pos){
        if(pos<=2) return 3;
        else if(pos <=5) return 6;
        else return 9;
    }
    /*
    *Verificacion de la ubicacion actual en el tablero
    */
    public boolean getBloque(int i, int j, int valor){
        int posFila = BloqueActual(i);
        int posColumna = BloqueActual(j);
        //Recorer filas y columnas del cuadrante actual
        for(int k = posFila -3; k < posFila; k++){
            for(int l = posColumna -3; l < posColumna; l++){
            //Verificar si el valor que queremos ingresar se encuentra en el bloque actual
            if(tablero[k][l]==valor){
                return false;
            }
        }
      }
            return true;
    }
    /*
    *Metodo para que en todas las posiciones del tablero sean 0
    */
    public void limpiarSudoku() {
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[0].length; j++) {
                tablero[i][j] = 0;
            }
        }
    }
    /*
    *Verificacion de las filas del tablero
    */
    public boolean getFilas(int i, int valor){
        //Recorer la fila
        for (int j = 0; j < tablero[i].length; j++){
            //Verificacion si el numero ya esta en dicha fila
            if (tablero[i][j]==valor){
                return false;
            }
        }
        return true;
    }
    
    /**
     *Verificacion de las columnas del tablero
     */
    public boolean getColumna(int j, int valor){
        //Recorer columnas
        for(int i = 0; i < tablero.length; i++){
            //Verificacion si el numero ya esta en dicha columna
            if(tablero[i][j]== valor){
                return false;
            }
        }
        return true;
    }
    /**
     * Método para inicializar y resolver el juego de Sudoku.
     */
    public void inicializar(){
        resolverTablero();
        for(int i = 0; i < tablero.length; i++){
            for (int j = 0; j < tablero[0].length; j++){ 
                System.out.print(tablero[i][j]);
                if(!(j==tablero[0].length-1)) System.out.print(" - ");
            }
            System.out.println();
        }
    }
    
    /*
    * Este metodo genera numeros aleatorios en el primer, quinto y 
    * ultimo cuadrante del tablero
    */
    public void generarSudoku(int nivel){
        limpiarSudoku();
        Random random = new Random();
        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int num = random.nextInt(9) + 1;
                if (getBloque(i, j, num)) {
                    tablero[i][j] = num;
                } else {
                    j--;
                }
            }
        }

        for (int i = 3; i < 6; i++) {
            for (int j = 3; j < 6; j++) {
                int num = random.nextInt(9) + 1;
                if (getBloque(i, j, num)) {
                    tablero[i][j] = num;
                } else {
                    j--;
                }
            }
        }

        for (int i = 6; i < 9; i++) {
            for (int j = 6; j < 9; j++) {
                int num = random.nextInt(9) + 1;
                if (getBloque(i, j, num)) {
                    tablero[i][j] = num;
                } else {
                    j--;
                }
            }
        }
        resolverTablero();

        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[0].length; j++) {
                int aux = j;
                int rand = random.nextInt(nivel);
                j += rand;
                for (int k = aux; k < j && k < tablero.length; k++) {
                    tablero[i][k] = 0;
                }
            }
        }
    }
    public int[][] getTablero() {
        return tablero;
    }

    public void setTablero(int[][] tablero) {
        this.tablero = tablero;
    }
    
}
