
package main;

import models.Tablero;
import views.Gameplay;

/**
 *
 * @author andrisharaizaespinoza
 */
public class Main {

    public static void main(String[] args) {
       
       Gameplay sudoku = new Gameplay();
       sudoku.setVisible(true);
       
    }
}
